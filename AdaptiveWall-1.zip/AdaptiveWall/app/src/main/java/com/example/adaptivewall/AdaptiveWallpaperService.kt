package com.example.adaptivewall

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RectF
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.abs
import kotlin.math.max

class AdaptiveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = AdaptiveEngine()

    inner class AdaptiveEngine : Engine() {
        private var bmp: Bitmap? = null
        private var integral = LongArray(0)
        private var ew = 0
        private var eh = 0
        private var w = 0
        private var h = 0
        private var s = 1f
        private var ox = 0f
        private var oy = 0f
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        override fun onSurfaceChanged(holder: SurfaceHolder, f: Int, width: Int, height: Int) {
            w = width; h = height
            reload(); draw(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible && w > 0) { reload(); draw(surfaceHolder) }
        }

        // Ikonların duracağı alanlar (ızgara + dock)
        private fun iconRects(): List<RectF> {
            val p = getSharedPreferences("aw", MODE_PRIVATE)
            val cols = p.getInt("cols", 5); val rows = p.getInt("rows", 6)
            val l = w * 0.05f; val r = w * 0.95f; val t = h * 0.14f; val b = h * 0.80f
            val cw = (r - l) / cols; val ch = (b - t) / rows
            val out = ArrayList<RectF>()
            for (i in 0 until rows) for (j in 0 until cols) {
                val cx = l + cw * (j + .5f); val cy = t + ch * (i + .5f)
                out.add(RectF(cx - cw * .3f, cy - ch * .35f, cx + cw * .3f, cy + ch * .35f))
            }
            for (j in 0 until 4) { // dock
                val cx = w * (0.125f + 0.25f * j); val cy = h * 0.92f
                out.add(RectF(cx - cw * .3f, cy - ch * .3f, cx + cw * .3f, cy + ch * .3f))
            }
            return out
        }

        private fun reload() {
            val f = File(filesDir, "wall.jpg")
            if (!f.exists() || w == 0) return
            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
            val bm = BitmapFactory.decodeFile(f.path, o) ?: return
            bmp = bm
            // Detay (kenar) enerji haritası + integral görüntü
            ew = 96; eh = max(1, 96 * bm.height / bm.width)
            val sm = Bitmap.createScaledBitmap(bm, ew, eh, true)
            val g = IntArray(ew * eh) {
                val c = sm.getPixel(it % ew, it / ew)
                ((c shr 16 and 255) * 3 + (c shr 8 and 255) * 6 + (c and 255)) / 10
            }
            integral = LongArray((ew + 1) * (eh + 1))
            for (y in 0 until eh) for (x in 0 until ew) {
                val e = (if (x + 1 < ew) abs(g[y * ew + x + 1] - g[y * ew + x]) else 0) +
                        (if (y + 1 < eh) abs(g[(y + 1) * ew + x] - g[y * ew + x]) else 0)
                integral[(y + 1) * (ew + 1) + x + 1] = e + integral[y * (ew + 1) + x + 1] +
                        integral[(y + 1) * (ew + 1) + x] - integral[y * (ew + 1) + x]
            }
            layoutImage(bm.width, bm.height)
        }

        private fun meanEnergy(r: RectF, x: Float, y: Float, sc: Float, bw: Int, bh: Int): Float {
            val kx = ew / bw.toFloat(); val ky = eh / bh.toFloat()
            val x0 = (((r.left - x) / sc) * kx).toInt().coerceIn(0, ew - 1)
            val x1 = (((r.right - x) / sc) * kx).toInt().coerceIn(x0 + 1, ew)
            val y0 = (((r.top - y) / sc) * ky).toInt().coerceIn(0, eh - 1)
            val y1 = (((r.bottom - y) / sc) * ky).toInt().coerceIn(y0 + 1, eh)
            val n = ew + 1
            val sum = integral[y1 * n + x1] - integral[y0 * n + x1] -
                    integral[y1 * n + x0] + integral[y0 * n + x0]
            return sum.toFloat() / ((x1 - x0) * (y1 - y0))
        }

        // Fotoğrafın detaylı kısımları ikonların arasına, sakin kısımları ikonların altına gelsin
        private fun layoutImage(bw: Int, bh: Int) {
            val cells = iconRects()
            val base = max(w / bw.toFloat(), h / bh.toFloat())
            var best = Float.MAX_VALUE
            for (k in floatArrayOf(1f, 1.15f, 1.3f)) {
                val sc = base * k; val iw = bw * sc; val ih = bh * sc
                for (i in 0..8) for (j in 0..8) {
                    val x = (w - iw) * i / 8f; val y = (h - ih) * j / 8f
                    var cost = 0f
                    for (r in cells) cost += meanEnergy(r, x, y, sc, bw, bh)
                    cost *= k // aşırı yakınlaştırmayı cezalandır
                    if (cost < best) { best = cost; s = sc; ox = x; oy = y }
                }
            }
        }

        private fun draw(holder: SurfaceHolder) {
            val bm = bmp ?: return
            val c = holder.lockCanvas() ?: return
            try {
                c.drawColor(0xFF000000.toInt())
                c.save(); c.translate(ox, oy); c.scale(s, s)
                c.drawBitmap(bm, 0f, 0f, paint)
                c.restore()
            } finally { holder.unlockCanvasAndPost(c) }
        }
    }
}
