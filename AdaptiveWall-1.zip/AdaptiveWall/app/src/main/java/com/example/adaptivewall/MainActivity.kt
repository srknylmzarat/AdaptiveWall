package com.example.adaptivewall

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("aw", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 3, pad, pad)
        }
        fun field(hint: String, key: String, def: Int) = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt(key, def).toString())
        }
        val cols = field("Ikon sütunu", "cols", 5)
        val rows = field("Ikon satırı", "rows", 6)
        val pick = Button(this).apply {
            text = "Fotoğraf seç"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1)
            }
        }
        val apply = Button(this).apply {
            text = "Duvar kağıdını uygula"
            setOnClickListener {
                prefs.edit()
                    .putInt("cols", cols.text.toString().toIntOrNull()?.coerceIn(3, 8) ?: 5)
                    .putInt("rows", rows.text.toString().toIntOrNull()?.coerceIn(3, 9) ?: 6)
                    .apply()
                startActivity(
                    Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                        WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        ComponentName(this@MainActivity, AdaptiveWallpaperService::class.java)
                    )
                )
            }
        }
        listOf(cols, rows, pick, apply).forEach { root.addView(it) }
        setContentView(root)
    }

    @Deprecated("Basit tutmak için eski API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.openInputStream(uri)?.use { i ->
                    File(filesDir, "wall.jpg").outputStream().use { o -> i.copyTo(o) }
                }
                prefs.edit().putLong("v", System.currentTimeMillis()).apply()
                Toast.makeText(this, "Fotoğraf kaydedildi", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
